# Outside, Around Coastal

A small, responsive website for finding outdoor places around the Grand Strand. Built with HTML, CSS, and vanilla JavaScript. No account, API key, build step, or framework needed.

## Run it

Open `index.html` in a browser. For a local development server, run `python -m http.server 8000` in this folder and open `http://localhost:8000`.

## Features

- Search place names, areas, activities, and descriptions.
- Filter by beach, walking, wildlife, or saved spots.
- Save favorites in browser localStorage. Storage is only on that device/browser.
- Pick a random matching spot with the Surprise me button.
- Open official information and Google Maps directions.
- Responsive layout and keyboard-friendly controls.

## How it works

The `spots` array at the top of `script.js` is the local data source. `matches()` combines a case-insensitive search with the active filter; `render()` updates the cards and result count. Save buttons update a Set and persist its IDs in localStorage. To add a place, add an object to `spots` with a unique ID, an official source link, and a map search query.

The guide is a portfolio demo. It does not provide live conditions, travel times, or guaranteed availability. Check official pages for current admission, hours, closures, and access. The Sculptured Oak Trail is inside Myrtle Beach State Park and shares its admission/access rules.

## Sources for place descriptions

- [Myrtle Beach State Park](https://southcarolinaparks.com/myrtle-beach) and [trails](https://southcarolinaparks.com/myrtle-beach/trails)
- [Huntington Beach State Park](https://southcarolinaparks.com/huntington-beach) and [trails](https://southcarolinaparks.com/huntington-beach/trails)
- [Horry County parks, including Vereen Memorial Historical Gardens](https://www.horrycountysc.gov/departments/parksandrecreation/parks/)

## AI use and my contribution

This initial version was generated with AI assistance from Codex based on my request for a small GitHub project tailored to a software engineering internship. AI helped plan the scope, draft the HTML/CSS/JavaScript, and organize the README. Before describing this as my own work in an application, I will run it, review the code, make changes myself, and document what I personally changed and tested. I should be able to explain the filtering, rendering, and saved-places logic in an interview.

## Ideas I can implement next

1. Replace one sample place with an outdoor location I've visited and write my own description.
2. Add an activity filter or accessibility information from an official source.
3. Add a map preview or a small automated test for filtering.

## Publishing on GitHub

Create a new public repository, upload `index.html`, `styles.css`, `script.js`, and `README.md`, then turn on GitHub Pages in the repository settings if you want a live demo link. Add a screenshot to this README after viewing the site in your browser.
