// Edit this array to add or change spots. Descriptions and activities are based
// on the official pages linked below; verify details before visiting.
const spots = [
  { id: 'myrtle-beach-state-park', name: 'Myrtle Beach State Park', area: 'Myrtle Beach', type: 'beach', activities: ['beach', 'walk'], description: 'A beach day with a side of short woodland trails. Try the easy Sculptured Oak Trail if you want a break from the sand.', website: 'https://southcarolinaparks.com/myrtle-beach', mapQuery: 'Myrtle Beach State Park South Carolina' },
  { id: 'huntington-beach-state-park', name: 'Huntington Beach State Park', area: 'Murrells Inlet', type: 'wildlife', activities: ['beach', 'walk', 'wildlife'], description: 'Beach, marsh, and wildlife viewing in one trip. The Sandpiper Pond Trail is an easy walk through maritime forest.', website: 'https://southcarolinaparks.com/huntington-beach', mapQuery: 'Huntington Beach State Park South Carolina' },
  { id: 'vereen-memorial-gardens', name: 'Vereen Memorial Gardens', area: 'Little River', type: 'walk', activities: ['walk', 'wildlife'], description: 'Nature trails and boardwalks wind through forest and marsh beside the Intracoastal Waterway.', website: 'https://www.horrycountysc.gov/departments/parksandrecreation/parks/', mapQuery: 'Vereen Memorial Gardens Little River South Carolina' },
  { id: 'sculptured-oak-trail', name: 'Sculptured Oak Trail', area: 'Myrtle Beach State Park', type: 'walk', activities: ['walk', 'wildlife'], description: 'A short, easy walk among oaks, wax myrtles, hollies, and magnolias inside Myrtle Beach State Park.', website: 'https://southcarolinaparks.com/myrtle-beach/trails', mapQuery: 'Sculptured Oak Trail Myrtle Beach State Park South Carolina' }
];

const storageKey = 'coastal-outdoor-finder-saved';
let saved = new Set();
try {
  const stored = JSON.parse(localStorage.getItem(storageKey) || '[]');
  if (Array.isArray(stored)) saved = new Set(stored.filter(id => spots.some(spot => spot.id === id)));
} catch { /* Browsing still works if saved data is unavailable. */ }

const results = document.querySelector('#results');
const count = document.querySelector('#count');
const empty = document.querySelector('#empty');
const search = document.querySelector('#search');
const filters = document.querySelector('#filters');
let activeFilter = 'all';

function matches(spot) {
  const text = search.value.trim().toLowerCase();
  const searchable = [spot.name, spot.area, spot.description, ...spot.activities].join(' ').toLowerCase();
  return (!text || searchable.includes(text)) && (activeFilter === 'all' || (activeFilter === 'saved' ? saved.has(spot.id) : spot.activities.includes(activeFilter)));
}

function render() {
  const visible = spots.filter(matches);
  results.replaceChildren();
  for (const spot of visible) {
    const card = document.createElement('article');
    card.className = 'card';
    // All display strings originate in the local, developer-controlled array.
    card.innerHTML = `<div class="card-main"><div class="card-top"><span class="tag">${spot.type.toUpperCase()}</span><button class="save" type="button" data-id="${spot.id}" aria-label="${saved.has(spot.id) ? 'Remove' : 'Save'} ${spot.name}" aria-pressed="${saved.has(spot.id)}" title="Save this place">${saved.has(spot.id) ? '♥' : '♡'}</button></div><h3>${spot.name}</h3><p>${spot.description}</p><div class="card-meta">${spot.area.toUpperCase()}</div></div><div class="card-links"><a href="${spot.website}" target="_blank" rel="noopener noreferrer">Official info ↗</a><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(spot.mapQuery)}" target="_blank" rel="noopener noreferrer">Directions ↗</a></div>`;
    results.append(card);
  }
  count.textContent = `${visible.length} ${visible.length === 1 ? 'PLACE' : 'PLACES'} FOUND`;
  empty.hidden = visible.length !== 0;
}

search.addEventListener('input', render);
filters.addEventListener('click', event => {
  const button = event.target.closest('button[data-filter]');
  if (!button) return;
  activeFilter = button.dataset.filter;
  for (const item of filters.querySelectorAll('button')) {
    const selected = item === button;
    item.classList.toggle('active', selected);
    item.setAttribute('aria-pressed', String(selected));
  }
  render();
});
results.addEventListener('click', event => {
  const button = event.target.closest('button[data-id]');
  if (!button) return;
  if (saved.has(button.dataset.id)) saved.delete(button.dataset.id);
  else saved.add(button.dataset.id);
  try { localStorage.setItem(storageKey, JSON.stringify([...saved])); } catch { /* Ignore disabled storage. */ }
  render();
});
document.querySelector('#surprise').addEventListener('click', () => {
  const choices = spots.filter(matches);
  if (!choices.length) { search.value = ''; activeFilter = 'all'; filters.querySelector('[data-filter="all"]').click(); }
  const pool = choices.length ? choices : spots;
  const chosen = pool[Math.floor(Math.random() * pool.length)];
  const card = [...results.querySelectorAll('.card')].find(item => item.querySelector('h3').textContent === chosen.name);
  card?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  card?.querySelector('h3')?.setAttribute('tabindex', '-1');
  card?.querySelector('h3')?.focus({ preventScroll: true });
});
render();
